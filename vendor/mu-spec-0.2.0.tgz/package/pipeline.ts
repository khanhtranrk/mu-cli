import { parse } from "yaml";

export const pipelineFields = ["inputs", "outputs", "context", "prepare", "nodes", "events"] as const;
const rootFields = new Set<string>([
  "kind", "schema_version", "expression_engine", "workloads", "routines", ...pipelineFields,
]);

function isMapping(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

/** Published Pipeline YAML uses the YAML 1.2 core schema by default. */
export function parsePipelineDocument(source: string): Record<string, unknown> {
  const root: unknown = parse(source, { version: "1.2", uniqueKeys: true, maxAliasCount: 100 });
  if (!isMapping(root) || root.kind !== "pipeline" || root.schema_version !== 1) {
    throw new Error("Expected kind: pipeline and schema_version: 1");
  }
  for (const key of Object.keys(root)) {
    if (!rootFields.has(key)) throw new Error(`Unknown Pipeline field: ${key}`);
  }
  return root;
}
